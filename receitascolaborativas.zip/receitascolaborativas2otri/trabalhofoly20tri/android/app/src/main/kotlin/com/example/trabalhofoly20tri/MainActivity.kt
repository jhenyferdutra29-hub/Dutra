package com.example.trabalhofoly20tri

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
