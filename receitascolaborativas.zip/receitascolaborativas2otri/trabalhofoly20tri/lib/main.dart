import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp( //autenticação do firebase
    options: const FirebaseOptions(
      apiKey: "AIzaSyDh9B5zBdHTC5P7TnuMrYAYGCd--9-g-O8",
      authDomain: "receitas-colaborativas.firebaseapp.com",
      projectId: "receitas-colaborativas",
      storageBucket: "receitas-colaborativas.firebasestorage.app",
      messagingSenderId: "970093055078",
      appId: "1:970093055078:web:ec00ec250cae7fb988f1a7",
    ),
  );

  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Receitas Colaborativas',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        useMaterial3: true,
      ),
      home: const VerificacaoAutenticacao(),
      debugShowCheckedModeBanner: false,
    );
  }
}


// tela de autenticação

class VerificacaoAutenticacao extends StatefulWidget {
  const VerificacaoAutenticacao({super.key});

  @override
  State<VerificacaoAutenticacao> createState() => _VerificacaoAutenticacaoState();
}

class _VerificacaoAutenticacaoState extends State<VerificacaoAutenticacao> {
  bool _carregando = true;
  bool _estaLogado = false;

  @override
  void initState() {
    super.initState();
    _verificarSessaoSalva();
  }

  // Uso do Shared Preferences para persistir estado da sessão
  Future<void> _verificarSessaoSalva() async {
    final prefs = await SharedPreferences.getInstance();
    final usuarioSalvo = prefs.getString('usuario_email');

    if (usuarioSalvo != null && FirebaseAuth.instance.currentUser != null) {
      setState(() {
        _estaLogado = true;
        _carregando = false;
      });
    } else {
      setState(() {
        _estaLogado = false;
        _carregando = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return _estaLogado ? const TelaReceitas() : const TelaLogin();
  }
}

class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  bool _modoCadastro = false;
  String _mensagemErro = '';

  Future<void> _autenticar() async {
    final email = _emailController.text.trim();
    final senha = _senhaController.text.trim();

    if (email.isEmpty || senha.isEmpty) {
      setState(() => _mensagemErro = 'Preencha todos os campos.');
      return;
    }

    try {
      if (_modoCadastro) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email,
          password: senha,
        );
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: senha,
        );
      }

      // Salva a sessão no Shared Preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('usuario_email', email);

      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const TelaReceitas()),
        );
      }
    } on FirebaseAuthException catch (e) {
      setState(() => _mensagemErro = e.message ?? 'Erro na autenticação.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_modoCadastro ? 'Cadastrar Conta' : 'Login - Receitas'),
        backgroundColor: Colors.deepOrange,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.restaurant_menu, size: 80, color: Colors.deepOrange),
                const SizedBox(height: 16),
                Text(
                  _modoCadastro ? 'Criar uma nova conta' : 'Entrar no aplicativo',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'E-mail',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _senhaController,
                  decoration: const InputDecoration(
                    labelText: 'Senha',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                ),
                if (_mensagemErro.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(_mensagemErro, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _autenticar,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                    minimumSize: const Size.fromHeight(50),
                  ),
                  child: Text(_modoCadastro ? 'Cadastrar' : 'Entrar'),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      _modoCadastro = !_modoCadastro;
                      _mensagemErro = '';
                    });
                  },
                  child: Text(
                    _modoCadastro
                        ? 'Já tem conta? Faça Login'
                        : 'Não tem conta? Cadastre-se',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// TELA PRINCIPAL DE RECEITAS
// -----------------------------------------------------------------------------
class TelaReceitas extends StatefulWidget {
  const TelaReceitas({super.key});

  @override
  State<TelaReceitas> createState() => _TelaReceitasState();
}

class _TelaReceitasState extends State<TelaReceitas> {
  final _tituloController = TextEditingController();
  final _tempoController = TextEditingController();
  final _tipoController = TextEditingController();

  // CONTROLLERS DOS FILTROS 
  final _filtroTextoController = TextEditingController();
  int _filtroTempoMaximo = 180; 

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('usuario_email'); // Limpa o Shared Preferences

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const TelaLogin()),
      );
    }
  }

  Future<void> _adicionarReceita() async {
    if (_tituloController.text.trim().isEmpty) return;

    await FirebaseFirestore.instance.collection('Receitas').add({ 
      'receita': _tituloController.text.trim(),
      'tempopreparo': int.tryParse(_tempoController.text) ?? 0,
      'tipo': _tipoController.text.trim().toLowerCase(),
    });

    _tituloController.clear();
    _tempoController.clear();
    _tipoController.clear();
  }

  @override
  Widget build(BuildContext context) {
    final usuarioAtual = FirebaseAuth.instance.currentUser?.email ?? 'Usuário';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Receitas Colaborativas'),
        backgroundColor: Colors.deepOrange,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: _logout,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // BARRA DE BOAS-VINDAS COM E-MAIL DO USUÁRIO
            Container(
              padding: const EdgeInsets.all(8.0),
              color: Colors.orange.shade100,
              width: double.infinity,
              child: Text(
                'Conectado como: $usuarioAtual',
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),

            // FORMULÁRIO DE ADIÇÃO DE RECEITA
            Card(
              margin: const EdgeInsets.all(12),
              color: Colors.orange.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '➕ Adicionar Nova Receita',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _tituloController,
                      decoration: const InputDecoration(labelText: 'Nome da Receita'),
                    ),
                    TextField(
                      controller: _tempoController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Tempo de Preparo (min)'),
                    ),
                    TextField(
                      controller: _tipoController,
                      decoration: const InputDecoration(labelText: 'Tipo (ex: sobremesa, salgado)'),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _adicionarReceita,
                      icon: const Icon(Icons.send),
                      label: const Text('Publicar Receita'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),

        
            // painel de filtros na base de dados
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '🔍 Filtros na Base de Dados (Consultas):',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // FILTRO 1: Por texto do tipo/categoria
                    TextField(
                      controller: _filtroTextoController,
                      decoration: const InputDecoration(
                        labelText: 'Filtrar por Tipo (ex: sobremesa)',
                        isDense: true,
                        prefixIcon: Icon(Icons.search),
                      ),
                      onChanged: (value) {
                        setState(() {}); // Atualiza o StreamBuilder
                      },
                    ),
                    const SizedBox(height: 8),
                    // FILTRO 2: Por Tempo Máximo de Preparo
                    Row(
                      children: [
                        Text('Tempo Máx: $_filtroTempoMaximo min'),
                        Expanded(
                          child: Slider(
                            value: _filtroTempoMaximo.toDouble(),
                            min: 5,
                            max: 180,
                            divisions: 35,
                            label: '$_filtroTempoMaximo min',
                            onChanged: (val) {
                              setState(() {
                                _filtroTempoMaximo = val.round();
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const Divider(),

            // LISTA COM FILTROS APLICADOS DIRECTAMENTE NO FIRESTORE
            StreamBuilder<QuerySnapshot>(
              stream: _obterQueryComFiltros().snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Erro: ${snapshot.error}'));
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data?.docs ?? [];

                if (docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text('Nenhuma receita encontrada com esses filtros.'),
                  );
                }

                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    final receitaId = docs[index].id;

                    return CardItemReceita(
                      receitaId: receitaId,
                      titulo: data['receita'] ?? 'Sem título',
                      tempo: data['tempopreparo'] ?? 0,
                      tipo: data['tipo'] ?? 'N/A',
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // APLICAÇÃO DOS 2 FILTROS/CONSULTAS AO FIRESTORE (ITEM C)
  Query _obterQueryComFiltros() {
    Query query = FirebaseFirestore.instance.collection('Receitas');

    // Consulta/Filtro 1: Tempo menor ou igual ao valor do Slider
    query = query.where('tempopreparo', isLessThanOrEqualTo: _filtroTempoMaximo);

    // Consulta/Filtro 2: Tipo de receita exato (se preenchido)
    final tipoFiltro = _filtroTextoController.text.trim().toLowerCase();
    if (tipoFiltro.isNotEmpty) {
      query = query.where('tipo', isEqualTo: tipoFiltro);
    }

    return query;
  }
}


// ITEM a e d: SUBCOLEÇÃO DE COMENTÁRIOS E INTERAÇÃO MULTIUSUÁRIO

class CardItemReceita extends StatefulWidget {
  final String receitaId;
  final String titulo;
  final dynamic tempo;
  final String tipo;

  const CardItemReceita({
    super.key,
    required this.receitaId,
    required this.titulo,
    required this.tempo,
    required this.tipo,
  });

  @override
  State<CardItemReceita> createState() => _CardItemReceitaState();
}

class _CardItemReceitaState extends State<CardItemReceita> {
  final _comentarioController = TextEditingController();

  Future<void> _adicionarComentario() async {
    if (_comentarioController.text.trim().isEmpty) return;

    final usuario = FirebaseAuth.instance.currentUser?.email ?? 'Anônimo';

    await FirebaseFirestore.instance
        .collection('Receitas')
        .doc(widget.receitaId)
        .collection('comentarios')
        .add({
      'texto': _comentarioController.text.trim(),
      'autorcomentario': usuario,
    });

    _comentarioController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(12),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.titulo,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text('⏱️️ Tempo: ${widget.tempo} min | 🏷️ Tipo: ${widget.tipo}'),
            const Divider(height: 24),
            const Text(
              '💬 Comentários:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // SUBCOLEÇÃO 'comentarios'
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('Receitas')
                  .doc(widget.receitaId)
                  .collection('comentarios')
                  .snapshots(),
              builder: (context, subSnapshot) {
                if (subSnapshot.connectionState == ConnectionState.waiting) {
                  return const CircularProgressIndicator();
                }

                final comentarios = subSnapshot.data?.docs ?? [];

                if (comentarios.isEmpty) {
                  return const Text('Nenhum comentário ainda. Seja o primeiro!');
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: comentarios.map((docComentario) {
                    final comData = docComentario.data() as Map<String, dynamic>;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2.0),
                      child: Text(
                        '• ${comData['texto']} (por ${comData['autorcomentario'] ?? 'Anônimo'})',
                        style: const TextStyle(fontStyle: FontStyle.italic),
                      ),
                    );
                  }).toList(),
                );
              },
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _comentarioController,
                    decoration: const InputDecoration(
                      hintText: 'Escreva um comentário...',
                      isDense: true,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.deepOrange),
                  onPressed: _adicionarComentario,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}