import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'auth_service.dart';
import 'login.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String _categoriaSelecionada = "Todas";
  double _tempoPreparoMaximo = 120.0;

  final List<String> _categoriasDisponiveis = const [
    "Todas",
    "Almoço/Janta",
    "Sobremesa",
    "Salgado",
    "Café da manhã/tarde",
  ];

  void _abrirDialogNovaReceita() {
    final formKeyDialog = GlobalKey<FormState>();
    final tituloCtrl = TextEditingController();
    final instrucoesCtrl = TextEditingController();
    final tempoCtrl = TextEditingController();
    String categoria = "Almoço/Janta";

    showDialog(
      context: context,
      builder: (contextDialog) => StatefulBuilder(
        builder: (contextDialog, setDialogState) => AlertDialog(
          title: const Text("Nova Receita"),
          content: SingleChildScrollView(
            child: Form(
              key: formKeyDialog,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: tituloCtrl,
                    decoration: const InputDecoration(labelText: "Título"),
                    validator: (v) =>
                        v == null || v.trim().isEmpty ? "Informe o título" : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: instrucoesCtrl,
                    decoration: const InputDecoration(
                      labelText: "Instruções da Receita",
                    ),
                    maxLines: 3,
                    validator: (v) => v == null || v.trim().isEmpty
                        ? "Informe as instruções"
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: tempoCtrl,
                    decoration: const InputDecoration(
                      labelText: "Tempo de Preparo (minutos)",
                    ),
                    keyboardType: TextInputType.number,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return "Informe o tempo em minutos";
                      }
                      if (int.tryParse(v) == null) {
                        return "Insira um número válido";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: categoria,
                    decoration: const InputDecoration(labelText: "Categoria"),
                    items: _categoriasDisponiveis
                        .where((c) => c != "Todas")
                        .map((c) =>
                            DropdownMenuItem(value: c, child: Text(c)))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setDialogState(() => categoria = v);
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(contextDialog),
              child: const Text("Cancelar"),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKeyDialog.currentState!.validate()) {
                  final user = _auth.currentUser;
                  if (user != null) {
                    final tempo = int.parse(tempoCtrl.text.trim());

                    await _firestore.collection('receitas').add({
                      'titulo': tituloCtrl.text.trim(),
                      'instrucoes': instrucoesCtrl.text.trim(),
                      'categoria': categoria,
                      'tempoPreparo': tempo,
                      'autorId': user.uid,
                      'autorNome': user.displayName ?? user.email ?? "Anónimo",
                      'dataCriacao': FieldValue.serverTimestamp(),
                    });

                    if (!mounted) return;
                    Navigator.pop(contextDialog);
                  }
                }
              },
              child: const Text("Publicar"),
            ),
          ],
        ),
      ),
    );
  }

  Query _obterConsultaFirestore() {
    Query query = _firestore.collection('receitas');
    if (_categoriaSelecionada != "Todas") {
      query = query.where('categoria', isEqualTo: _categoriaSelecionada);
    }
    return query;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Receitas Colaborativas"),
        backgroundColor: Colors.deepOrange,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            tooltip: "Sair",
            onPressed: () async {
              await AuthService.limparSessao();
              await _auth.signOut();
              if (!mounted) return;
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Card(
            margin: const EdgeInsets.all(12.0),
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Filtros de Pesquisa",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Text(
                        "Categoria: ",
                        style: TextStyle(fontWeight: FontWeight.w500),
                      ),
                      Expanded(
                        child: DropdownButton<String>(
                          isExpanded: true,
                          value: _categoriaSelecionada,
                          items: _categoriasDisponiveis
                              .map((c) =>
                                  DropdownMenuItem(value: c, child: Text(c)))
                              .toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _categoriaSelecionada = val);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        "Tempo máx: ${_tempoPreparoMaximo.toInt()} min",
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                      Expanded(
                        child: Slider(
                          value: _tempoPreparoMaximo,
                          min: 10,
                          max: 180,
                          divisions: 17,
                          activeColor: Colors.deepOrange,
                          label: "${_tempoPreparoMaximo.toInt()} min",
                          onChanged: (val) =>
                              setState(() => _tempoPreparoMaximo = val),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _obterConsultaFirestore().snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text("Erro ao carregar dados: ${snapshot.error}"),
                  );
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final todosOsDocumentos = snapshot.data!.docs;
                final receitasFiltradas = todosOsDocumentos.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final tempo = data.containsKey('tempoPreparo')
                      ? (data['tempoPreparo'] as num).toInt()
                      : 0;
                  return tempo <= _tempoPreparoMaximo.toInt();
                }).toList();

                if (receitasFiltradas.isEmpty) {
                  return const Center(
                    child: Text(
                      "Nenhuma receita encontrada com os filtros atuais.",
                      style: TextStyle(color: Colors.grey),
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: receitasFiltradas.length,
                  itemBuilder: (context, index) {
                    final receitaDoc = receitasFiltradas[index];
                    final data = receitaDoc.data() as Map<String, dynamic>;

                    final String titulo = data['titulo'] ?? 'Sem Título';
                    final String categoria = data['categoria'] ?? 'Geral';
                    final int tempoPreparo = data.containsKey('tempoPreparo')
                        ? (data['tempoPreparo'] as num).toInt()
                        : 0;
                    final String autorNome = data['autorNome'] ?? 'Anónimo';
                    final String instrucoes = data['instrucoes'] ?? '';

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12.0),
                      elevation: 1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ExpansionTile(
                        leading: const CircleAvatar(
                          backgroundColor: Colors.deepOrange,
                          foregroundColor: Colors.white,
                          child: Icon(Icons.restaurant),
                        ),
                        title: Text(
                          titulo,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          "$categoria • $tempoPreparo min • Por: $autorNome",
                        ),
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                "Instruções:\n$instrucoes",
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          ),
                          const Divider(height: 1),
                          _SecaoComentarios(receitaId: receitaDoc.id),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _abrirDialogNovaReceita,
        backgroundColor: Colors.deepOrange,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Nova Receita"),
      ),
    );
  }
}

class _SecaoComentarios extends StatefulWidget {
  final String receitaId;

  const _SecaoComentarios({required this.receitaId});

  @override
  State<_SecaoComentarios> createState() => _SecaoComentariosState();
}

class _SecaoComentariosState extends State<_SecaoComentarios> {
  final _comentarioCtrl = TextEditingController();

  @override
  void dispose() {
    _comentarioCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Container(
      color: Colors.grey.shade50,
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Comentários e Substituições de Ingredientes:",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 13,
              color: Colors.deepOrange,
            ),
          ),
          const SizedBox(height: 8),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('receitas')
                .doc(widget.receitaId)
                .collection('comentarios')
                .orderBy('data', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return const Text("Erro ao carregar os comentários.");
              }
              if (!snapshot.hasData) {
                return const SizedBox.shrink();
              }

              final comentarios = snapshot.data!.docs;

              if (comentarios.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 6.0),
                  child: Text(
                    "Sem comentários ainda. Seja o primeiro a interagir!",
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                );
              }

              return ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: comentarios.length,
                itemBuilder: (context, idx) {
                  final c = comentarios[idx].data() as Map<String, dynamic>;
                  final String texto = c['texto'] ?? '';
                  final String autor = c['autorNome'] ?? 'Anónimo';

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.comment, size: 16, color: Colors.grey),
                        const SizedBox(width: 8),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 13,
                              ),
                              children: [
                                TextSpan(
                                  text: "$autor: ",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                TextSpan(text: texto),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _comentarioCtrl,
                  decoration: const InputDecoration(
                    hintText: "Adicione um comentário ou dica...",
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.send, color: Colors.deepOrange),
                onPressed: () async {
                  final texto = _comentarioCtrl.text.trim();
                  if (texto.isNotEmpty && user != null) {
                    _comentarioCtrl.clear();

                    await FirebaseFirestore.instance
                        .collection('receitas')
                        .doc(widget.receitaId)
                        .collection('comentarios')
                        .add({
                      'texto': texto,
                      'autorId': user.uid,
                      'autorNome': user.displayName ?? user.email ?? "Anónimo",
                      'data': FieldValue.serverTimestamp(),
                    });
                  }
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}