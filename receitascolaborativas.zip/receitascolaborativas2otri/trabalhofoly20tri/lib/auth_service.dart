import 'package:shared_preferences/shared_preferences.dart';

/// Serviço de persistência local utilizando SharedPreferences.
class AuthService {
  static const String _keyNome = 'user_nome';
  static const String _keyEmail = 'user_email';

  /// Salva o Nome e o E-mail do utilizador no SharedPreferences.
  static Future<void> salvarSessao({
    required String nome,
    required String email,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyNome, nome.trim());
    await prefs.setString(_keyEmail, email.trim());
  }

  /// Recupera os dados do utilizador previamente salvos.
  static Future<Map<String, String?>> obterSessao() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'nome': prefs.getString(_keyNome),
      'email': prefs.getString(_keyEmail),
    };
  }

  /// Remove os dados salvos no SharedPreferences ao efetuar logout.
  static Future<void> limparSessao() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyNome);
    await prefs.remove(_keyEmail);
  }
}